# Codecademy: Freelance Website Development
## Project: Colmar Academy - Bootstrap refactoring
